# Merge Tactics Tracker Pro — PWA

این پوشه نسخه PWA Tracker است. برای نصب روی Home Screen باید فایل‌ها روی یک آدرس HTTPS (یا localhost) سرو شوند؛ باز کردن index.html از داخل Telegram یا به صورت content:// نصب‌پذیر نیست.

## نصب روی گوشی
1. این پوشه را روی یک سرویس استاتیک HTTPS قرار بده.
2. لینک `index.html` را با Chrome باز کن.
3. از منوی Chrome گزینه **Add to Home screen** یا **Install app** را بزن.
4. بعد از نصب، Tracker مثل یک اپ مستقل از صفحه اصلی اجرا می‌شود.

## ذخیره‌سازی
Matchها همچنان کاملاً دستی هستند. داده‌ها در همان دستگاه و همان Web App ذخیره می‌شوند.
Tracker علاوه بر localStorage یک Snapshot داخلی در IndexedDB هم نگه می‌دارد تا در صورت خالی شدن localStorage، آخرین وضعیت قابل بازیابی باشد.

## Backup
دکمه Backup JSON داخل خود Tracker همچنان برای بکاپ دستی کامل وجود دارد.
